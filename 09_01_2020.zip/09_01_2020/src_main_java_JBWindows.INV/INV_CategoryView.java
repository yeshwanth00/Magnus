package JBWindows.INV;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.sikuli.script.FindFailed;
import commonClass.BaseClass;
import commonClass.GenericMethods;

public class INV_CategoryView extends BaseClass {
	// Header elements
	@FindBy(id = "picClose")
	WebElement btnClose;
	@FindBy(id = "lblCaption")
	WebElement PageCaption;
	@FindBy(id = "picLogo")
	WebElement HeaderJBLogo;
	@FindBy(id = "lblNoData")
	WebElement lblNoData;

	// Details pane element
	@FindBy(id = "lblCategory")
	WebElement lblCategory;
	@FindBy(id = "lblCategoryType")
	WebElement lblCategoryType;
	@FindBy(id = "lblDiscount")
	WebElement lblDiscount;

	// Master page elements
	@FindBy(id = "INV_CategoryView")
	WebElement pageName;
	@FindBy(id = "txtSearch")
	WebElement txtSearch;

	// Entry OR Edit screen elements
	@FindBy(id = "picCategory")
	WebElement ImagePath;
	@FindBy(id = "txtCategory")
	WebElement txtCategory;
	@FindBy(id = "cboCategoryTypeCode")
	WebElement cboCategoryTypeCode;
	@FindBy(id = "lookUpDiscountRule")
	WebElement lookUpDiscountRule;
	@FindBy(id = "lookUpParentCategory")
	WebElement lookUpParentCategory;
	@FindBy(id = "memoDescription")
	WebElement memoDescription;

	// Buttons elements
	@FindBy(id = "btnAdd")
	WebElement btnAdd;
	@FindBy(id = "btnSave")
	WebElement btnEdit;
	@FindBy(id = "btnSave")
	WebElement btnSave;
	@FindBy(id = "btnCancel")
	WebElement btnCancel;
	@FindBy(id = "btnOk")
	WebElement btnOk;

	// Upload popup element
	@FindBy(id = "1148")
	WebElement uploadFile;
	// -------------2-Feb-2018---modified by Moumita----------------
	@FindBy(id = "1")
	WebElement selectFile;
	@FindBy(id = "2")
	WebElement selectFileCancel;
	@FindBy(name = "Delete Image")
	WebElement DeleteImage;

	/* 28-June-18-----Added by Moumita */
	@FindBy(id = "grdCategory")
	WebElement grdRecordList;
	@FindBy(id = "lblNoData")
	WebElement noCategoryLabel;

	// WebElement Initialization
	public INV_CategoryView() {
		PageFactory.initElements(driver, this);
	}

	public void activatePage() {
		pageName.click();
	}

	// Actions
	public void clickCreateNewButton() {
		btnAdd.click();
	}

	public void clickEditButton() {
		btnEdit.click();
	}

	public void clickSaveButton() {
		btnSave.click();
	}

	public void clickCloseButton() {
		GenericMethods.fnwait(5);
		driver.findElement(By.id("picLogo")).click();
		btnClose.click();
	}

	public void clickOnImage() {
		ImagePath.click();
	}

	// Category Creation:
	public void fn_Verify_New_Category_Creation(String Image, String CategoryName, String CategoryType,
			String DiscountRule, String ParentCategory, String Description) {

		if (btnAdd.isDisplayed()) {
			btnAdd.click();

			if (ImagePath.isDisplayed()) {
				Actions action = new Actions(driver);
				action.moveToElement(ImagePath).doubleClick().build().perform();
				GenericMethods.fn_Verifly_UploadFile(Image);

			} else {
				fnWriteSteps("Fail", "Image Type is not displayed in UI");
			}

			if (txtCategory.isDisplayed()) {
				txtCategory.sendKeys(CategoryName);

			} else {

				fnWriteSteps("Fail", "CategoryName field is not displayed in UI");
			}
			if (cboCategoryTypeCode.isDisplayed()) {
				cboCategoryTypeCode.sendKeys(CategoryType);
				cboCategoryTypeCode.click();
			} else {
				fnWriteSteps("Fail", "CategoryCode Type is not displayed in UI");
			}
			if (lookUpDiscountRule.isDisplayed()) {
				lookUpDiscountRule.sendKeys(DiscountRule);
				lookUpDiscountRule.click();
			} else {
				fnWriteSteps("Fail", "Discount Type is not displayed in UI");
			}
			if (lookUpParentCategory.isDisplayed()) {
				lookUpParentCategory.sendKeys(ParentCategory);
				lookUpParentCategory.click();
			} else {
				fnWriteSteps("Fail", "ParentCategory Type is not displayed in UI");
			}
			if (memoDescription.isDisplayed()) {
				memoDescription.sendKeys(Description);
			} else {
				fnWriteSteps("Fail", "Description Type is not displayed in UI");
			}
			if (btnSave.isDisplayed())
				btnSave.click();
			System.out.println("ProductCategory has been created & Saved");
			
		} else {
			System.out.println("Add button is not displyed");

		}

		/*
		 * String Actual =
		 * driver.findElement(By.id("lblCategory")).getAttribute("Name"); String
		 * Expected = CategoryName; if(Actual.contains(Expected)){
		 * System.out.println("Successfully Created_ProductCategory Saved");
		 * fnWriteSteps("Pass", "Successfully Created_ProductCategory Saved"); } else {
		 * System.out.println("UnSuccessfully Created_ProductCategory not Saved"); }
		 */
	}

	public boolean Verify_ProductCategoryCreation_SaveorNot(String Categoryname) {

		if (txtSearch.isDisplayed()) {
			txtSearch.sendKeys(Categoryname);

		} else {
			fnWriteSteps("Fail", "CategoryName is not displayed in UI");

		}
		String Actual = driver.findElement(By.id("lblCategory")).getAttribute("Name");
		
     if (Actual.substring(15, 24).equalsIgnoreCase(Categoryname.trim())) {
			
		   return true;
		}
		   return false;
	}

	// This method is to verify Editing category works or not.
	// input parameter is Category Name, field name, new filed value
	
	public void verifyEditCategoryFeature(String Image, String CategoryName, String CategoryType, String DiscountRule1,
			String DiscountRule2, String ParentCategory, String Description, String OldCategoryName) throws FindFailed {

		txtSearch.sendKeys(OldCategoryName);
		btnEdit.click();

		if (DeleteImage.isDisplayed()) {
			DeleteImage.click();
			btnOk.click();
			if (ImagePath.isDisplayed()) {
				Actions action = new Actions(driver);
				action.moveToElement(ImagePath).doubleClick().build().perform();
				GenericMethods.fn_Verifly_UploadFile(Image);
			}

		} else {
			fnWriteSteps("Fail", "Image Type is not displayed in UI");
		}
		if (txtCategory.isDisplayed()) {
			txtCategory.clear();
			txtCategory.sendKeys(CategoryName);
		} else {
			fnWriteSteps("Fail", "CategoryName field is not displayed in UI");
		}
		if (cboCategoryTypeCode.isDisplayed()) {
			cboCategoryTypeCode.clear();
			cboCategoryTypeCode.sendKeys(CategoryType);
			cboCategoryTypeCode.submit();
		} else {
			fnWriteSteps("Fail", "CategoryCode Type is not displayed in UI");
		}
		if (lookUpDiscountRule.isDisplayed()) {
			lookUpDiscountRule.clear();
			lookUpDiscountRule.sendKeys(DiscountRule1);
			lookUpDiscountRule.submit();
			GenericMethods.fnwait(2);
			lookUpDiscountRule.sendKeys(DiscountRule2);
			lookUpDiscountRule.submit();
		} else {
			fnWriteSteps("Fail", "Discount Type is not displayed in UI");
		}
		if (lookUpParentCategory.isDisplayed()) {
			lookUpParentCategory.clear();
			lookUpParentCategory.sendKeys(ParentCategory);
			lookUpParentCategory.click();
		} else {
			fnWriteSteps("Fail", "ParentCategory Type is not displayed in UI");
		}
		if (memoDescription.isDisplayed()) {
			memoDescription.clear();
			memoDescription.sendKeys(Description);
		
			
		} else {
			fnWriteSteps("Fail", "Description Type is not displayed in UI");
		}

		btnSave.click();
		System.out.println("ProductCategory has been Updated & Saved ");
		GenericMethods.fnwait(2);
	}
		public boolean Verify_ProductCategoryUpdate_SaveorNot(String Categoryname) {

			if (txtSearch.isDisplayed()) {
				txtSearch.sendKeys(Categoryname);

			} else {
				fnWriteSteps("Fail", "CategoryName is not displayed in UI");

			}
			String Actual = driver.findElement(By.id("lblCategory")).getAttribute("Name");
			if (Actual.substring(15, 19).equalsIgnoreCase(Categoryname.trim())) {
				
			   return true;
			}
			   return false;
		}
		
		public void fnVerifyCategoryDelete(String Categoryname) {
			txtSearch.sendKeys(Categoryname);
			GenericMethods.fnwait(1);
			GenericMethods.fnVerifyMasterRecordDelete(grdRecordList);
			btnOk.click();
			System.out.println("Created ProductCategory Deleted");
		}
		public void click_On_Yes_Button() {
			driver.findElement(By.id("lblHeader")).click();
			GenericMethods.fnwait(2);
			btnOk.click();
		}
		public boolean Verify_ProductCategoryDelete_SaveorNot(String Categoryname) {

			if (txtSearch.isDisplayed()) {
				txtSearch.clear();
				txtSearch.click();
				txtSearch.sendKeys(Categoryname);
			
				
			} else {
				fnWriteSteps("Fail", "CategoryName is not displayed in UI");

			}
			GenericMethods.fnwait(8);
			
			String Actual = driver.findElement(By.id("lblCategory")).getAttribute("Name");
		
			    if (!Actual.contains(Categoryname)) {
				
			   return true;
			}
			   return false;
		}
		
	
		
	

	// ---------2-Feb-2018 added by Moumita-------------------
	// This method is to verify all the fields are visible or not

	public void verifyFieldVisibility() {

		if (btnAdd.isDisplayed()) {
			btnAdd.click();

			if (ImagePath.isDisplayed()) {
				fnWriteSteps("Pass", "Category image upload field is present");
			} else {
				fnWriteSteps("Fail", "Category image upload field is not present");
			}
			if (txtCategory.isDisplayed()) {
				fnWriteSteps("Pass", "Category field is present");
			} else {
				fnWriteSteps("Fail", "Category field is not present");
			}
			if (cboCategoryTypeCode.isDisplayed()) {
				fnWriteSteps("Pass", "Category Type field is present");
			} else {
				fnWriteSteps("Fail", "Category Type field is not present");
			}
			if (lookUpDiscountRule.isDisplayed()) {
				fnWriteSteps("Pass", "Discount Rule field is present");
			} else {
				fnWriteSteps("Fail", "Discount Rule field is not present");
			}
			if (lookUpParentCategory.isDisplayed()) {
				fnWriteSteps("Pass", "Parent Category field is present");
			} else {
				fnWriteSteps("Fail", "Parent Category field is not present");
			}
			if (memoDescription.isDisplayed()) {
				System.out.println("Successfully all fields are Displayed");
				fnWriteSteps("Pass", "Description field is present");
			} else {
				fnWriteSteps("Fail", "Description field is not present");
			}
		}
	}

	// This method is to verify all the fields are enable or not

	public void verifyFieldEnableOrNot() {

		if (btnAdd.isDisplayed()) {
			btnAdd.click();

			/*
			 * Due to some code issue I have commented this part if
			 * (picCategory.isEnabled()) { GenericMethods.DoubleClickAction("Window",
			 * picCategory); GenericMethods.fnwait(2); selectFileCancel.click();
			 * fnWriteSteps("Pass", "Category image upload field is present" ); } else {
			 * fnWriteSteps("Fail", "Category image upload field is not present"); }
			 */
			if (txtCategory.isEnabled()) {
				txtCategory.click();
				fnWriteSteps("Pass", "Category field is enable");
			} else {
				fnWriteSteps("Fail", "Category field is not enable");
			}
			if (cboCategoryTypeCode.isEnabled()) {
				cboCategoryTypeCode.click();
				fnWriteSteps("Pass", "Category Type field is enable");
			} else {
				fnWriteSteps("Fail", "Category Type field is not enable");
			}
			if (lookUpDiscountRule.isEnabled()) {
				lookUpDiscountRule.click();
				fnWriteSteps("Pass", "Discount Rule field is enable");
			} else {
				fnWriteSteps("Fail", "Discount Rule field is not enable");
			}
			if (lookUpParentCategory.isEnabled()) {
				lookUpParentCategory.click();
				fnWriteSteps("Pass", "Parent Category field is enable");
			} else {
				fnWriteSteps("Fail", "Parent Category field is not enable");
			}
			if (memoDescription.isEnabled()) {
				memoDescription.click();
				System.out.println("Successfully all fields are Enabled");
				fnWriteSteps("Pass", "Description field is enable");
			} else {
				fnWriteSteps("Fail", "Description field is not present");
			}
		}
	}
	/*
	 * Due to some code issue I have commented this part if
	 * (picCategory.isEnabled()) { GenericMethods.DoubleClickAction("Window",
	 * picCategory); GenericMethods.fnwait(2); selectFileCancel.click();
	 * fnWriteSteps("Pass", "Category image upload field is present"); } else {
	 * fnWriteSteps("Fail", "Category image upload field is not present"); }
	 */

	/* 28-June-18-----Added by Moumita */
	/*
	 * This is the method to delete the record by delete icon from master page
	 */
	

	/* 28-June-18-----Added by Moumita */
	/*
	 * This is the method to verify the record has been deleted successfully or not
	 */
	public void fnVerifyCategoryDeleteSuccessfulOrNot(String strCategoryName) {
		txtSearch.clear();
		txtSearch.sendKeys(strCategoryName);
		String gridNoDataLabel = null;

		WebElement messageEle = driver.findElement(By.id("lblNoData"));
		gridNoDataLabel = messageEle.getAttribute("Name");
		if (gridNoDataLabel.contains("No category found")) {
			fnWriteSteps("pass", "Record has been deleted successfully");
		} else {
			fnWriteSteps("fail", "Record has not been deleted");
		}

	}
}
