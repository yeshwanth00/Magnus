package JBWindows_Masters;

import java.io.IOException;
import org.apache.log4j.xml.DOMConfigurator;
import org.sikuli.script.FindFailed;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import JBWindows.APP.APP_Dashboard;
import JBWindows.APP.APP_Menu;
import JBWindows.INV.INV_CategoryView;
import JBWindows.SYS.Login;
import JBWindows.SYS.MessageBoxEffia;
import commonClass.ApplicationVariables;
import commonClass.BaseClass;
import commonClass.ExcelUtils;
import commonClass.GenericMethods;

public class ProductCategoriesPage_UnitTest extends BaseClass {
	Login refLogin;
	APP_Dashboard refDashboard;
	APP_Menu refMenu;
	INV_CategoryView refCategoryView;
	MessageBoxEffia refMessgBox;
	
   public ProductCategoriesPage_UnitTest() {
		super();
	}

	@BeforeSuite
	public void fnInitializeReporting() {
		fnInitializeReport();
	}

	@BeforeMethod
	public void fnBeforeMethod() throws InterruptedException, IOException {
		fnStartTestCase("fnBeforeMethod");
		fnInitializeWindowsSetup();
		DOMConfigurator.configure("log4j.xml");
		refLogin = new Login();
		refDashboard = new APP_Dashboard();
		refMenu = new APP_Menu();
		refCategoryView = new INV_CategoryView();
		refMessgBox = new MessageBoxEffia();
		
		
		String Username = ExcelUtils.fn_Get_Expected_Cell_Value_based_on_Execution_Status(
				ApplicationVariables.LoginMasterExcel, "EnvironmentDetails", "Execution", "Yes Win", "Username");
		String Password = ExcelUtils.fn_Get_Expected_Cell_Value_based_on_Execution_Status(
				ApplicationVariables.LoginMasterExcel, "EnvironmentDetails", "Execution", "Yes Win", "Password");
		refLogin.fnDoLogin(Username, Password);
		GenericMethods.fnwait(10);
		refDashboard.OpenMenuList();
		GenericMethods.fnwait(2);
		refMenu.OpenPage("Product Categories");
		GenericMethods.fnwait(1);
		fnWriteSteps("Pass", "Application Open Successfully");
		fnEndTestCase();

	}
	@Test 
	public void fnVerifyFieldVisibility() throws IOException, InterruptedException {
		fnStartTestCase("Verify all the fields of Category add entry are present or not ");

		refCategoryView.verifyFieldVisibility();
		fnEndTestCase();

	}

	@Test 
	public void fnVerifyFieldEnableOrNot() throws IOException, InterruptedException {
		fnStartTestCase("Verify all the fields of Category add entry are enable or not");

		refCategoryView.verifyFieldEnableOrNot();
		fnEndTestCase();

	}
	
	@Test 
	public void fnverifyParent_Product_CategoryCreation(){
		fnStartTestCase("Verify Parent_Product_category Creation");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Category";
	    int RowNumber = 7;
	    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CategoryType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String DiscountRule = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
		String ParentCategory = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		refCategoryView.fn_Verify_New_Category_Creation(Image,CategoryName,CategoryType,DiscountRule,ParentCategory,Description);
		boolean result = refCategoryView.Verify_ProductCategoryCreation_SaveorNot(CategoryName);
		Assert.assertTrue(result);
		fnWriteSteps("Pass", "Parent_Product_Category has been created & Saved");
		fnEndTestCase();
	}
	@Test 
	public void fnverify_Product_CategoryCreation_for_withoutInternet_Validation(){
		fnStartTestCase("Verify Product_category Creation");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Category";
	    int RowNumber = 11;
	    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CategoryType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String DiscountRule = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
		String ParentCategory = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		refCategoryView.fn_Verify_New_Category_Creation(Image,CategoryName,CategoryType,DiscountRule,ParentCategory,Description);
		boolean result = refCategoryView.Verify_ProductCategoryCreation_SaveorNot(CategoryName);
		Assert.assertTrue(result);
		fnWriteSteps("Pass", "Product_Category has been created & Saved");
		fnEndTestCase();
	}
	
	@Test 
	public void fnverifyNewProduct_CategoryCreation(){
		fnStartTestCase("Verify New category Creation");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Category";
	    int RowNumber = 1;
	    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CategoryType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String DiscountRule = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
		String ParentCategory = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		refCategoryView.fn_Verify_New_Category_Creation(Image,CategoryName,CategoryType,DiscountRule,ParentCategory,Description);
		boolean result = refCategoryView.Verify_ProductCategoryCreation_SaveorNot(CategoryName);
		Assert.assertTrue(result);
		fnWriteSteps("Pass", "New Category has been created & Saved");
		fnEndTestCase();
	}
	
    @Test 
    public void fnVerifyEditProductCategoryFeature() throws FindFailed{
	fnStartTestCase("Verify Edit ProductCategory Feature");
	String StrExcelPath = ApplicationVariables.MasterExcelPath;
    String StrSheetName = "Category";
    int RowNumber = 6;
    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
	String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	String CategoryType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	String DiscountRule1 = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	String DiscountRule2 = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	String ParentCategory = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
	String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
	String OldcategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
	refCategoryView.verifyEditCategoryFeature(Image,CategoryName,CategoryType,DiscountRule1,DiscountRule2,ParentCategory,Description,OldcategoryName);
	boolean result = refCategoryView.Verify_ProductCategoryUpdate_SaveorNot(CategoryName);
	Assert.assertTrue(result);
	fnWriteSteps("Pass", "ProductCategory has been Updated & Saved");
	fnEndTestCase();
	
}
    @Test 
    public void fnVerifyDeleteParent_Product_CategoryFeature() {
    	
    	fnStartTestCase("Verify DeleteParent_ProductCategory Feature");
    	String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Category";
        int RowNumber = 7;
        String Categoryname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
    	refCategoryView.fnVerifyCategoryDelete(Categoryname);
    	refCategoryView.click_On_Yes_Button();
    	fnWriteSteps("Pass", "Parent_ProductCategory not Deleted ");
    	fnEndTestCase();
    }
    @Test 
    public void fnVerifyDelete_Product_CategoryFeature_for_withoutInternet_Validation() {
    	
    	fnStartTestCase("Verify ProductCategory Feature");
    	String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Category";
        int RowNumber = 11;
        String Categoryname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
    	refCategoryView.fnVerifyCategoryDelete(Categoryname);
    	refCategoryView.click_On_Yes_Button();
    	fnWriteSteps("Pass", "ProductCategory not Deleted ");
    	fnEndTestCase();
    }
  
    @Test 
    public void fnVerifyDeleteCategoryFeature() {
    	
    	fnStartTestCase("Verify Delete_ProductCategory Feature");
    	String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Category";
        int RowNumber = 6;
        String Categoryname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
    	refCategoryView.fnVerifyCategoryDelete(Categoryname);
    	boolean result = refCategoryView.Verify_ProductCategoryUpdate_SaveorNot(Categoryname);
    	Assert.assertTrue(result);
    	fnWriteSteps("Pass", "ProductCategory has been Deleted ");
    	fnEndTestCase();
    }
    
  
   @AfterMethod
	public void fnAfterMethod() {
    	fnStartTestCase("fnAfterMethod");
		refCategoryView.clickCloseButton();
		GenericMethods.fnwait(2);
		refDashboard.ClickLogOutButton();
		GenericMethods.fnwait(1);
		refMessgBox.ExitApplication_Yes();
		GenericMethods.fnwait(5);
		refLogin.ClickCloseButton();
		fnWriteSteps("Pass", "Application Close Successfully");
		fnEndTestCase();
	}
    @AfterSuite
    public void fnAfterSuit() {
    	fnGenerateReport();
		
	}

}
	
	

