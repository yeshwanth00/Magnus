package JBWindows_Masters;
    
    import org.apache.log4j.xml.DOMConfigurator;
    import org.sikuli.script.FindFailed;
    import org.testng.Assert;
    import org.testng.annotations.AfterMethod;
	import org.testng.annotations.AfterSuite;
	import org.testng.annotations.Test;
	import java.io.IOException;

	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.BeforeSuite;

	import JBWindows.APP.APP_Dashboard;
	import JBWindows.APP.APP_Menu;
	import JBWindows.INV.INV_ProductAliasEntry;
	import JBWindows.INV.INV_ProductPriceListItems;
	import JBWindows.INV.INV_ProductPurchasing;
	import JBWindows.INV.INV_ProductView;
	import JBWindows.PUR.PUR_Suppliers;
	import JBWindows.SAL.SAL_SelectMofifier;
	import JBWindows.SYS.Login;
	import JBWindows.SYS.MessageBoxEffia;
	import commonClass.ApplicationVariables;
	import commonClass.BaseClass;
	import commonClass.ExcelUtils;
	import commonClass.GenericMethods;

	public class ProductPage_Test extends BaseClass {

		Login refLogin;
		APP_Dashboard refDashboard;
		APP_Menu refMenu;
		INV_ProductView refProducts;
		MessageBoxEffia refMessgBox;
		INV_ProductPriceListItems refProductPriceListItems;
		INV_ProductPurchasing refProductPurchasing;
		PUR_Suppliers refSupplierPage;
		SAL_SelectMofifier refProductModifier;
		INV_ProductAliasEntry refProductAliasEntry;

		public ProductPage_Test() {
			super();
		}

		@BeforeSuite
		public void fnInitializeReporting() {
			fnInitializeReport();
		}

		@BeforeMethod
		public void fnBeforeMethod() throws InterruptedException, IOException {
			fnStartTestCase("fnBeforeMethod");
			fnInitializeWindowsSetup();
			DOMConfigurator.configure("log4j.xml");
			refLogin = new Login();
			refDashboard = new APP_Dashboard();
			refMenu = new APP_Menu();
			refProducts = new INV_ProductView();
			refMessgBox = new MessageBoxEffia();
			refProductPriceListItems = new INV_ProductPriceListItems();
			refProductPurchasing = new INV_ProductPurchasing();
			refSupplierPage = new PUR_Suppliers();
			refProductModifier = new SAL_SelectMofifier();
			refProductAliasEntry = new INV_ProductAliasEntry();

			String Username = ExcelUtils.fn_Get_Expected_Cell_Value_based_on_Execution_Status(
					ApplicationVariables.LoginMasterExcel, "EnvironmentDetails", "Execution", "Yes Win", "Username");
			String Password = ExcelUtils.fn_Get_Expected_Cell_Value_based_on_Execution_Status(
					ApplicationVariables.LoginMasterExcel, "EnvironmentDetails", "Execution", "Yes Win", "Password");
			refLogin.fnDoLogin(Username, Password);
			GenericMethods.fnwait(10);
			refDashboard.OpenMenuList();
			GenericMethods.fnwait(2);
			refMenu.OpenPage("products");
			GenericMethods.fnwait(1);
			fnWriteSteps("Pass", "Application Open Successfully");
			fnEndTestCase();

		}
		@Test 
		public void fnVerifyFieldVisibility() throws IOException, InterruptedException {
			fnStartTestCase("Verify all the fields of Product add entry are present or not ");

			refProducts.verifyFieldVisibility();

			fnEndTestCase();

		}

		@Test 
		public void fnVerifyFieldEnableOrNot() throws IOException, InterruptedException {
			fnStartTestCase("Verify all the fields of Product add entry are enable or not");

			refProducts.verifyFieldEnableOrNot();

			fnEndTestCase();

		}
		@Test 
		public void FnVerify_Active_Product_Creation(){
			fnStartTestCase("Verify Active Product Creation");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
		    String StrSheetName = "Products";
		    int RowNumber = 1;
		    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
			String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
			String ProductCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
			String ProductType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
			String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
			String ParentProduct = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		    String Brand = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
			String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		    String HSNCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
			String Unit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
			String Department = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
			String StndsaleMaxRetailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
			String StndPurchasemaxretailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
			String StndsaleUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,15);
			String StndPurchaseUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,16);
			String TaxGroup = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
			String inactive= ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,26);
			refProducts.verify_NewProduct_Creation(Image,ProductName,ProductCode,ProductType,CategoryName,ParentProduct,Brand,Description,HSNCode,Unit,TaxGroup,Department,StndsaleMaxRetailPrice,StndPurchasemaxretailPrice,StndsaleUnitPrice,StndPurchaseUnitPrice,inactive);
			 boolean result = refProducts.Verify_NewProductCreation_SaveorNot(ProductName);
				Assert.assertTrue(result);
			fnWriteSteps("Pass", "Active_Product has been Created & Saved" );
			fnEndTestCase();
			
		}
		@Test 
		public void FnVerify_InActive_Product_Creation(){
			fnStartTestCase("Verify InActive Product Creation");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
		    String StrSheetName = "Products";
		    int RowNumber = 2;
		    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
			String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
			String ProductCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
			String ProductType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
			String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
			String ParentProduct = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		    String Brand = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
			String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		    String HSNCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
			String Unit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
			String Department = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
			String StndsaleMaxRetailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
			String StndPurchasemaxretailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
			String StndsaleUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,15);
			String StndPurchaseUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,16);
			String TaxGroup = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
			String inactive= ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,26);
			refProducts.verify_NewProduct_Creation(Image,ProductName,ProductCode,ProductType,CategoryName,ParentProduct,Brand,Description,HSNCode,Unit,TaxGroup,Department,StndsaleMaxRetailPrice,StndPurchasemaxretailPrice,StndsaleUnitPrice,StndPurchaseUnitPrice,inactive);
			 boolean result = refProducts.Verify_NewProductCreation_SaveorNot(ProductName);
				Assert.assertTrue(result);
			fnWriteSteps("Pass", "InActive_Product has been Created & Saved" );
			fnEndTestCase();
			
		}
		@Test 
		public void FnVerify_Product_Creation_for_WithoutInternet_Validation(){
			fnStartTestCase("Verify Product Creation");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
		    String StrSheetName = "Products";
		    int RowNumber = 5;
		    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
			String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
			String ProductCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
			String ProductType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
			String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
			String ParentProduct = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		    String Brand = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
			String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		    String HSNCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
			String Unit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
			String Department = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
			String StndsaleMaxRetailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
			String StndPurchasemaxretailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
			String StndsaleUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,15);
			String StndPurchaseUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,16);
			String TaxGroup = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
			String inactive= ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,26);
			refProducts.verify_NewProduct_Creation(Image,ProductName,ProductCode,ProductType,CategoryName,ParentProduct,Brand,Description,HSNCode,Unit,TaxGroup,Department,StndsaleMaxRetailPrice,StndPurchasemaxretailPrice,StndsaleUnitPrice,StndPurchaseUnitPrice,inactive);
			 boolean result = refProducts.Verify_NewProductCreation_SaveorNot(ProductName);
				Assert.assertTrue(result);
			fnWriteSteps("Pass", "Product has been Created & Saved" );
			fnEndTestCase();
			
		}
		@Test 
		public void FnVerify_New_Product_Creation(){
			fnStartTestCase("Verify New Product Creation");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
		    String StrSheetName = "Products";
		    int RowNumber = 3;
		    String Image = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
			String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
			String ProductCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
			String ProductType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
			String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
			String ParentProduct = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		    String Brand = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
			String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		    String HSNCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
			String Unit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
			String Department = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
			String StndsaleMaxRetailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
			String StndPurchasemaxretailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
			String StndsaleUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,15);
			String StndPurchaseUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,16);
			String TaxGroup = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
			String inactive= ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,26);
			refProducts.verify_NewProduct_Creation(Image,ProductName,ProductCode,ProductType,CategoryName,ParentProduct,Brand,Description,HSNCode,Unit,TaxGroup,Department,StndsaleMaxRetailPrice,StndPurchasemaxretailPrice,StndsaleUnitPrice,StndPurchaseUnitPrice,inactive);
			 boolean result = refProducts.Verify_NewProductCreation_SaveorNot(ProductName);
				Assert.assertTrue(result);
			fnWriteSteps("Pass", "New_Product has been Created & Saved" );
			fnEndTestCase();
			
		}
		@Test 
		public void fnVerifyEditProductFeature() throws FindFailed{
			fnStartTestCase("Verify Edit Product Feature");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
		    String StrSheetName = "Products";
		    int RowNumber = 8;
		    String OldProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,19);
		    String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
			String CategoryName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		    String HSNCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
			String Unit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
			String Brand = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
			String Description = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
			String ProductCode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
			String StndPurchaseMaxRetailprice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
			String StndPurchaseUnitprice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,16);
			String StndPurchaseunitPrice1 = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,24);
			String StndPurchaseTaxGroup = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,20);
			String StndPurchaseDiscount = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
			String StndsaleUnitPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,15);
			String StndsaleunitPrice1 = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,24);
			String StndsaleMaxRetailPrice = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
			String StndsaleTaxGroup = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
			String StndsaleDiscount = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
			refProducts.verifyEditProductFeature(OldProductName,ProductName,CategoryName,HSNCode,Unit,Brand,Description,ProductCode,StndsaleMaxRetailPrice,StndPurchaseMaxRetailprice,StndsaleUnitPrice,StndsaleunitPrice1,StndPurchaseUnitprice,StndPurchaseunitPrice1,StndsaleTaxGroup,StndPurchaseTaxGroup,StndsaleDiscount,StndPurchaseDiscount);
			 boolean result = refProducts.Verify_EditProductFeature_SaveorNot(ProductName);
				Assert.assertTrue(result);
			fnWriteSteps("Pass", "Product has been Updated & Saved" );
			fnEndTestCase();
			
		}
		@Test 
		public void fnDeleteProduct() {
			fnStartTestCase("Verify DeleteProduct Feature");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
	        String StrSheetName = "Products";
	        int RowNumber = 8;
	        String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	        refProducts.fnVerifyProductDelete(ProductName);
	    	boolean result = refProducts.Verify_ProductDelete_SaveorNot(ProductName);
	    	Assert.assertTrue(result);
	    	fnWriteSteps("pass", "Product has been Deleted");
	    	fnEndTestCase();
		}
		@Test 
		public void fnDelete_Product__for_WithoutInternet() {
			fnStartTestCase("Verify Delete Product Feature");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
	        String StrSheetName = "Products";
	        int RowNumber = 5;
	        String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	        refProducts.fnVerifyProductDelete(ProductName);
	        refProducts.click_On_Yes_Button();
	    	fnWriteSteps("pass", "Product not Deleted");
	    	fnEndTestCase();
		}
		@Test 
		public void fnDeleteActive_Product() {
			fnStartTestCase("Verify Delete Active_Product Feature");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
	        String StrSheetName = "Products";
	        int RowNumber = 1;
	        String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	        refProducts.fnVerifyProductDelete(ProductName);
	    	boolean result = refProducts.Verify_ProductDelete_SaveorNot(ProductName);
	    	Assert.assertTrue(result);
	    	fnWriteSteps("pass", "Active_Product has been Deleted");
	    	fnEndTestCase();
		}
		@Test 
		public void fnDeleteInActive_Product() {
			fnStartTestCase("Verify Delete InActive_Product Feature");
			String StrExcelPath = ApplicationVariables.MasterExcelPath;
	        String StrSheetName = "Products";
	        int RowNumber = 2;
	        String ProductName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	        refProducts.fnVerifyProductDelete(ProductName);
	    	boolean result = refProducts.Verify_ProductDelete_SaveorNot(ProductName);
	    	Assert.assertTrue(result);
	    	fnWriteSteps("pass", "InActive_Product has been Deleted");
	    	fnEndTestCase();
		}
		@AfterMethod
		public void fnAfterMethod() {
			fnStartTestCase("fnAfterMethod");
			refProducts.clickCloseButton();
			GenericMethods.fnwait(2);
			refDashboard.ClickLogOutButton();
			GenericMethods.fnwait(1);
			refMessgBox.ExitApplication_Yes();
			GenericMethods.fnwait(2);
			refLogin.ClickCloseButton();
			fnWriteSteps("Pass", "Application Close Successfully");
			fnEndTestCase();
		}

		@AfterSuite
		public void fnAfterSuite() {	
			fnGenerateReport();
			
		}



}
