package JBWindows_Masters;

import java.io.IOException;
import org.apache.log4j.xml.DOMConfigurator;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import JBWindows.APP.APP_Dashboard;
import JBWindows.APP.APP_Menu;
import JBWindows.CRM.CRM_CustomerMaster;
import JBWindows.SYS.Login;
import JBWindows.SYS.MessageBoxEffia;
import commonClass.ApplicationVariables;
import commonClass.BaseClass;
import commonClass.ExcelUtils;
import commonClass.GenericMethods;
import junit.framework.Assert;

public class CustomerPage_UnitTest extends BaseClass {

	Login refLogin;
	APP_Dashboard refDashboard;
	APP_Menu refMenu;
	CRM_CustomerMaster refCustomerMaster;
	MessageBoxEffia refMessageBoxEffia;

	public CustomerPage_UnitTest() {
		super();
	}

	@BeforeSuite
	public void fnInitializeReporting() {
		fnInitializeReport();
	}	
	
	@BeforeMethod
	public void fnBeforeMethod() throws InterruptedException {	
		fnStartTestCase("fnBeforeMethod");
		fnInitializeWindowsSetup();
		DOMConfigurator.configure("log4j.xml");
		
		refLogin = new Login();
		refDashboard = new APP_Dashboard();
		refMenu = new APP_Menu();
		refMessageBoxEffia = new MessageBoxEffia();
		refCustomerMaster = new CRM_CustomerMaster();
		
		String Username = ExcelUtils.fn_Get_Expected_Cell_Value_based_on_Execution_Status(
				ApplicationVariables.LoginMasterExcel, "EnvironmentDetails", "Execution", "Yes Win", "Username");
		String Password = ExcelUtils.fn_Get_Expected_Cell_Value_based_on_Execution_Status(
				ApplicationVariables.LoginMasterExcel, "EnvironmentDetails", "Execution", "Yes Win", "Password");
		refLogin.fnDoLogin(Username, Password);
		GenericMethods.fnwait(10);
		refDashboard.OpenMenuList();
		GenericMethods.fnwait(2);
		refMenu.OpenPage("Customers");
		fnWriteSteps("Pass", "Application open Successfully");
		fnEndTestCase();

	}

	@Test 
	public void fnVerifyFieldVisibility_CustomerType_B2B() throws IOException, InterruptedException {
		fnStartTestCase("Verify all the fields of Customer add entry are present or not ");
		
		refCustomerMaster.verifyFieldVisibility(1);	
		
		fnEndTestCase();
	}
	@Test 
	public void fnVerifyFieldVisibilityCustomerType__B2C() throws IOException, InterruptedException {
		fnStartTestCase("Verify all the fields of Customer add entry are present or not ");
		
		refCustomerMaster.verifyFieldVisibility(5);	
		
		fnEndTestCase();
	}

	@Test 
	public void fnVerifyFieldEnableOrNotCustomerType_B2B() throws IOException, InterruptedException {
		fnStartTestCase("Verify all the fields of Customer add entry are enable or not");
		
		refCustomerMaster.verifyFieldEnableOrNot(1);
		
		fnEndTestCase(); 
	}
	@Test 
	public void fnVerifyFieldEnableOrNotCustomerType_B2C() throws IOException, InterruptedException {
		fnStartTestCase("Verify all the fields of Customer add entry are enable or not");
		
		refCustomerMaster.verifyFieldEnableOrNot(5);
		
		fnEndTestCase(); 
	}
	@Test 
	public void fnActive_CustomerCreation_CustomerType_B2C(){
		fnStartTestCase("Verify Active_B2C_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 5;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
		String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
	    String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
	    String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
	    String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the Active_B2C_Customer record has been created & Saved" );
        fnEndTestCase();
	}
	@Test 
	public void fnInActive_CustomerCreation_CustomerType_B2C(){
		fnStartTestCase("Verify Inactive_B2C_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 6;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
		String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
	    String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
	    String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
	    String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the Inactive_B2C_Customer record has been created & Saved" );
        fnEndTestCase();
	}
	@Test 
	public void fnCustomerCreation_CustomerType_B2C(){
		fnStartTestCase("Verify B2C_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 7;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
		String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
	    String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
	    String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
	    String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the B2C_Customer record has been created & Saved" );
        fnEndTestCase();
	}
	@Test 
	public void fnCustomerEdit_CustomerType_B2C(){
	
		fnStartTestCase("Verify B2C_Customer Edit ");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 8;
	    String CustType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String OldCustPhno = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,19);
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	    String CustLastName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	    String Phno = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
	    String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
	    String DoorNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
	    String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
	    String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
	    String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
	    String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
	    String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
	    String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
	    String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
	    String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	    String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
	    String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
	    String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	   refCustomerMaster.verifyEditCustomer(CustType,OldCustPhno,CustFirstName,CustLastName,Phno,Email,DoorNo,StreetName,State,City,Area,Pincode,Address,DOB,Anniversary,CreditDays,CreditLimit,VATNo,GSTIN);
	   boolean result = refCustomerMaster.Verify_EditCustomerCreation_SaveorNot(Phno);
	   Assert.assertTrue(result);
	   fnWriteSteps("Pass","the B2C_Customer records has been Updated & Saved" );
	   fnEndTestCase();
	}
	@Test 
	public void fnCustomerCreation_CustomerType_B2C_For_WithoutInternet(){
		fnStartTestCase("Verify B2C_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 10;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
		String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
		String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
		String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
	    String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
	    String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
	    String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the B2C_Customer record has been created & Saved" );
        fnEndTestCase();
	}
	
	@Test 
	public void fnActive_CustomerCreation_CustomerType_B2B(){
		fnStartTestCase("Verify Active_B2B_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 1;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	    String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	    String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
	    String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
		String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
		String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
		String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the Active_B2B_Customer records has been created & Saved" );
         fnEndTestCase();
	}
	@Test 
	public void fnInActive_CustomerCreation_CustomerType_B2B(){
		fnStartTestCase("Verify Inactive_B2B_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 2;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	    String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	    String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
	    String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
		String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
		String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
		String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		fnWriteSteps("Pass","the Inactive_B2B_Customer records has been created & Saved" );
         fnEndTestCase();
	}
	
	@Test 
	public void fnCustomerCreation_CustomerType_B2B(){
		fnStartTestCase("Verify B2B_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 3;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	    String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	    String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
	    String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
		String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
		String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
		String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the B2B_Customer records has been created & Saved" );
         fnEndTestCase();
	}
	@Test 
	public void fnCustomerEdit_CustomerType_B2B(){
	
		fnStartTestCase("Verify B2B_Customer Edit ");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 4;
	    String CustType = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String OldCustPhno = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,19);
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
	    String CustLastName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	    String Phno = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
	    String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
	    String DoorNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
	    String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
	    String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
	    String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
	    String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
	    String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
	    String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
	    String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
	    String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	    String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
	    String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
	    String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	   refCustomerMaster.verifyEditCustomer(CustType,OldCustPhno,CustFirstName,CustLastName,Phno,Email,DoorNo,StreetName,State,City,Area,Pincode,Address,DOB,Anniversary,CreditDays,CreditLimit,VATNo,GSTIN);
	   boolean result = refCustomerMaster.Verify_EditCustomerCreation_SaveorNot(Phno);
		Assert.assertTrue(result);
	   fnWriteSteps("Pass","the B2B_Customer records has been Updated & Saved" );
		fnEndTestCase();
	}
	@Test 
	public void fnCustomerCreation_CustomerType_B2B_For_WithoutInternet(){
		fnStartTestCase("Verify B2B_Customer creation"); 
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
	    String StrSheetName = "Customers";
	    int RowNumber = 9;
	    String CustFirstName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,0);
		String CustLastname = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,1);
	    String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
	    String PhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
		String AltPhoneNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,4);
		String Email = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,5);
		String DOB = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,6);
		String Anniversary = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,7);
	    String DoorNO = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,8);
		String StreetName = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,9);
	    String Area = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,10);
		String Pincode = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,11);
		String State = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,12);
		String City = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,13);
		String Address = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,14);
		String CreditLimit = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,17);
		String CreditDays = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,18);
		String VATNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,21);
	    String GSTIN = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,22);
	    String Inactive = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,23);
		refCustomerMaster.createNewCustomer(CustFirstName,CustLastname,Customertype,PhoneNO,AltPhoneNO,Email,DOB,Anniversary,DoorNO,StreetName,Area,Pincode,State,City,Address,CreditDays,CreditLimit,VATNo,GSTIN,Inactive);
		boolean result = refCustomerMaster.Verify_NewCustomerCreation_SaveorNot(PhoneNO);
		Assert.assertTrue(result);
		fnWriteSteps("Pass","the B2B_Customer records has been created & Saved" );
         fnEndTestCase();
	}
	
	@Test 
	public void fnDelete_CustomerType_B2C__for_WithoutInternet() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 10;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        refCustomerMaster.click_On_Yes_Button();
    	fnWriteSteps("pass", "B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	@Test
	public void fnCustomerDelete_CustomerType_B2C() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 8;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        boolean result = refCustomerMaster.Verify_CustomerDelete_SaveorNot(PhonNo);
        Assert.assertTrue(result);
        fnWriteSteps("pass", "The Active B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	@Test 
	public void fnActive_CustomerDelete_CustomerType_B2C() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 5;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        boolean result = refCustomerMaster.Verify_CustomerDelete_SaveorNot(PhonNo);
        Assert.assertTrue(result);
        fnWriteSteps("pass", "The Active B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	@Test 
	public void fnInActive_CustomerDelete_CustomerType_B2C() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 6;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        boolean result = refCustomerMaster.Verify_CustomerDelete_SaveorNot(PhonNo);
        Assert.assertTrue(result);
    	fnWriteSteps("pass", "The InActive B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	@Test 
	public void fnDelete_CustomerType_B2B__for_WithoutInternet() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 9;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        refCustomerMaster.click_On_Yes_Button();
    	fnWriteSteps("pass", "B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	@Test 
	public void fnCustomerDelete_CustomerType_B2B() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 4;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        boolean result = refCustomerMaster.Verify_CustomerDelete_SaveorNot(PhonNo);
        Assert.assertTrue(result);
    	fnWriteSteps("pass", "The Active B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	
	@Test 
	public void fnActive_CustomerDelete_CustomerType_B2B() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 1;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        boolean result = refCustomerMaster.Verify_CustomerDelete_SaveorNot(PhonNo);
        Assert.assertTrue(result);
    	fnWriteSteps("pass", "The Active B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	@Test 
	public void fnInActive_CustomerDelete_CustomerType_B2B() {
		fnStartTestCase("Verify Delete Customer Feature");
		String StrExcelPath = ApplicationVariables.MasterExcelPath;
        String StrSheetName = "Customers";
        int RowNumber = 2;
        String Customertype = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,2);
        String PhonNo = ExcelUtils.fnGetExcelCellValue(StrExcelPath, StrSheetName, RowNumber,3);
        refCustomerMaster.fnVerifyCustomerDelete(PhonNo,Customertype);
        boolean result = refCustomerMaster.Verify_CustomerDelete_SaveorNot(PhonNo);
        Assert.assertTrue(result);
    	fnWriteSteps("pass", "The InActive B2C_Customer not Deleted");
    	fnEndTestCase();
	}
	
	@AfterMethod
	public void fnAfterMethod() {
		fnStartTestCase("fnAfterMethod");
		refCustomerMaster.clickCloseButton();		
		GenericMethods.fnwait(2);
		refDashboard.ClickLogOutButton();
		GenericMethods.fnwait(1);
		refMessageBoxEffia.ExitApplication_Yes();
		GenericMethods.fnwait(5);
		refLogin.ClickCloseButton();
		fnWriteSteps("Pass", "Application Close Successfully");
		fnEndTestCase();
}

	@AfterSuite
	public void fnAfterSuite() {			
		
		fnGenerateReport();
		
	}

}
